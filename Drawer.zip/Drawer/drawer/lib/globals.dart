import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

myStyle14([Color? color, FontWeight? fw]) {
  return GoogleFonts.poppins(
      fontSize: 16, color: Colors.white, fontWeight: FontWeight.w300);
}

myStyle12([Color? color, FontWeight? fw]) {
  return GoogleFonts.poppins(
      fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold);
}
