// ignore_for_file: prefer_const_constructors

import 'package:drawer/globals.dart';
import 'package:flutter/material.dart';

class Drawerr extends StatelessWidget {
  const Drawerr({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 350,
      child: Container(
        color: Colors.black26,
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(20),
              child: Column(
                children: [
                  CircleAvatar(
                    backgroundImage: AssetImage("images/1.jpg"),
                    maxRadius: 40,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text("Bongani Nkosi", style: myStyle12()),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "nkosilebogang95@gmail.com",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                    ),
                  ),
                  SizedBox(
                    height: 40,
                  ),
                  MaterialButton(
                    minWidth: 240,
                    onPressed: () {},
                    child: Text(
                      "Sign Up",
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.edit,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Add Leads", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.star,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Redemption Points", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.plus_one,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Points", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.person,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Profile", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.assessment_sharp,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Dashboard", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.home,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Home", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 30,
                ),
                Divider(
                  thickness: 2.0,
                  color: Colors.white,
                ),
                SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                  child: Text(
                    "Communication",
                    style: myStyle14(),
                    textAlign: TextAlign.start,
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.lock,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Privacy Policy", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  // padding: EdgeInsets.all(20.0),
                  child: TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.call,
                        color: Colors.white,
                      ),
                      label: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                        child: Text("Contact Us", style: myStyle14()),
                      )),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  margin: EdgeInsets.all(5.0),
                  child: TextButton.icon(
                    onPressed: () {},
                    icon: Icon(
                      Icons.memory_rounded,
                      color: Colors.white,
                    ),
                    label: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                      child: Text("About Apps", style: myStyle14()),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
