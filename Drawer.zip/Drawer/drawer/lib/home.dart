import 'package:flutter/material.dart';
import 'package:drawer/drawer.dart';

class HomePage extends StatelessWidget {
  // const HomePage({ Key? key }) : super(key: key);
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Drawer"),
          leading: IconButton(
              onPressed: () => _scaffoldKey.currentState!.openDrawer(),
              icon: Icon(Icons.menu))),
      drawer: Drawerr(),
      key: _scaffoldKey,
      body: Container(
        color: Colors.black54,
      ),
    );
  }
}
